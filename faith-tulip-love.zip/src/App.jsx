export default function Home() {
  return (
    <div className="min-h-screen bg-pink-50 flex flex-col items-center justify-center p-6">
      <div className="max-w-xl w-full text-center space-y-6">
        <h1 className="text-4xl font-bold text-pink-700">To the Girl Who Loved Tulips</h1>

        <p className="text-lg text-gray-700">
          You once told me tulips were your favorite—graceful, delicate, and full of quiet strength. Just like you.
        </p>

        <p className="text-lg text-gray-700">
          This space is my promise. To grow into the man I should’ve been. To water what I once let wilt. To return with God at the center of everything.
        </p>

        <p className="italic text-pink-600">
          Then I'm still yours, if you'll have me. <br />
          It might not be today. <br />
          It might not be tomorrow. <br />
          But one day— <br />
          One day, I'll be ready. <br />
          To love you like the queen you are.
        </p>

        <p className="text-gray-600">Until then, I’ll keep growing. With faith. With discipline. With love.</p>

        <p className="text-sm text-gray-400">This site is for you, tulip queen. 🌷</p>
      </div>
    </div>
  );
}